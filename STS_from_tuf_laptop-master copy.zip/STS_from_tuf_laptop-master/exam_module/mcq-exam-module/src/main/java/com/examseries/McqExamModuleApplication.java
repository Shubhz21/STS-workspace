package com.examseries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class McqExamModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(McqExamModuleApplication.class, args);
	}

}

package com.examseries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class McqExamModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
